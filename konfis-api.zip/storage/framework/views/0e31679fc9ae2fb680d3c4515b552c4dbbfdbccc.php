</body>

</html><?php /**PATH C:\Projek\konfis-api\resources\views/templates/footer.blade.php ENDPATH**/ ?>