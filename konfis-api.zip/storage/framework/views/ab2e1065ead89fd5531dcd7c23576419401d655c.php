<?php echo $__env->make('templates.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<p><b>Tanggal</b> : <?php echo e($date); ?></p>

  <h2 style="font-family: Arial, Helvetica, sans-serif"><?php echo e($title); ?></h2>

  <table border="1" class="my-table" cellpadding="5">
    <tr>
      <th>No.</th>
      <th>Kode Bidang</th>
      <th>No. Urut</th>
      <th>No. DPA</th>
      <th>Uraian</th>
      <th>Tanggal</th>
      <th>Tanda Terima</th>
    </tr>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td align="center"><?php echo e($i+1); ?></td>
      <td align="center"><?php echo e($d->kode_bidang); ?></td>
      <td align="center"><?php echo e($d->no_urut); ?></td>
      <td align="center"><?php echo e($d->no_dpa); ?></td>
      <td><?php echo e($d->uraian); ?></td>
      <td align="center"><?php echo e(date("d/m/Y", strtotime($d->tanggal))); ?></td>
      <td align="center"><?php echo e($d->ttd); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </table>

<?php echo $__env->make('templates.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projek\konfis-api\resources\views/print_data_fisik.blade.php ENDPATH**/ ?>